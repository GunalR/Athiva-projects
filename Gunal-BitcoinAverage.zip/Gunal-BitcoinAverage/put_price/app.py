import json
import boto3
import os 

import requests


dynamodb = boto3.resource('dynamodb')

TABLE_NAME = os.environ['TABLE_NAME']

table = dynamodb.Table(TABLE_NAME)


def lambda_handler(event, context):


    key = "ZjE3NGFhMTNkNWFkNDJlY2I0OTQ2ZWJhMWViOWEyNTQ"


    y = requests.get("https://apiv2.bitcoinaverage.com/indices/global/ticker/BTCUSD",

    headers={'x-ba-key':key})

    if not y.ok:

        raise Exception(y.text)

    avg_data=y.json()

    price = str(avg_data['ask'])

    print(price)


    currency = avg_data['display_symbol']
    print(currency)

    timestamp = avg_data['display_timestamp']

    print(timestamp)

    provider = 'BitcoinAverage'


    data=table.put_item(
        Item={
            'Currency' : currency,
            'Provider': provider,
            'Price' : price,
            'Timestamp': timestamp
        }
      )
       
            
    return {"statusCode": 200,
                        "body": json.dumps(data)}


if __name__ == '__main__':
    event = {}

    lambda_handler(event, '')




        
