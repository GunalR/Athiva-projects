import json
import boto3
import os 



dynamodb = boto3.resource('dynamodb')

TABLE_NAME = os.environ['TABLE_NAME']

table = dynamodb.Table(TABLE_NAME)


def lambda_handler(event, context):



    Currency = event['Records'][0]['dynamodb']['NewImage']['Currency']['S']

    Provider = event['Records'][0]['dynamodb']['NewImage']['Provider']['S']

    Timestamp = event['Records'][0]['dynamodb']['NewImage']['Timestamp']['S']

    Price = event['Records'][0]['dynamodb']['NewImage']['Price']['S']


    data=table.put_item(
        Item={
            'Currency' : Currency,
            'Timestamp': Timestamp,
            'Provider': Provider,
            'Price' : Price
            
        }
      )
       
            
    return {"statusCode": 200,
                        "body": json.dumps(data)}


if __name__ == '__main__':
    event = {}

    lambda_handler(event, '')




        
