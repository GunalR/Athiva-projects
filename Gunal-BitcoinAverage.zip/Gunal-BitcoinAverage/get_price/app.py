import json
import boto3
import os 

from boto3.dynamodb.conditions import Key, Attr

dynamodb = boto3.resource('dynamodb')

TABLE_NAME = os.environ['TABLE_NAME']

table = dynamodb.Table(TABLE_NAME)


def lambda_handler(event, context):
  
    if "queryStringParameters" in event and "pk" in event["queryStringParameters"] and "sk" in event[
            "queryStringParameters"]:

        pk = event["queryStringParameters"]["pk"]
        
        sk = event["queryStringParameters"]["sk"]
          
        print(pk)
        print(sk)
          

        get_data = table.query(KeyConditionExpression=Key('Currency').eq(pk) & Key('Provider').eq(sk))
            
       
        item = {}

        if 'Items' in get_data:
            item = get_data['Items']

            print(item)
            
        return {"statusCode": 200,
                        "body": json.dumps(item[0])}
    else:
        pk = event["queryStringParameters"]["pk"]
            
        print(pk)
        
        get_data = table.query(KeyConditionExpression=Key('Currency').eq(pk))
        
        
        item = {}
        
        print(get_data)

        if 'Items' in get_data:
            item = get_data['Items']

        print(type(item))
            
        return {"statusCode": 200,
                        "body": json.dumps(item[0])}
      
      

      
            


        
